document.addEventListener("DOMContentLoaded", function () {
  const calendarEl = document.getElementById("calendar");

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: "dayGridMonth",
    height: "100%",
    headerToolbar: {
      left: "prev,next today",
      center: "title",
      right: "dayGridMonth,timeGridWeek,timeGridDay"
    },
    selectable: true,
    dateClick(info) {
      alert("Tanggal dipilih: " + info.dateStr);
    },
    events: []
  });

  calendar.render();
});

// =======================
// AURORA WAVE + BUBBLE
// (SAMA DENGAN LOGIN)
// =======================
const canvas = document.getElementById("fxCanvas");
const ctx = canvas.getContext("2d");

function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resize();
window.addEventListener("resize", resize);

let time = 0;

// -------- BUBBLES --------
const bubbles = Array.from({ length: 22 }, () => ({
  x: Math.random() * canvas.width,
  y: canvas.height + Math.random() * 200,
  r: Math.random() * 10 + 6,
  speed: Math.random() * 0.35 + 0.15,
  drift: Math.random() * 1000,
  alpha: Math.random() * 0.25 + 0.25
}));

function drawBubbles() {
  bubbles.forEach(b => {
    b.drift += 0.01;
    b.x += Math.sin(b.drift) * 0.2;
    b.y -= b.speed;

    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(59,255,179,${b.alpha})`;
    ctx.fill();

    if (b.y < -50) {
      b.y = canvas.height + 100;
      b.x = Math.random() * canvas.width;
    }
  });
}

// -------- WAVE --------
function drawWave() {
  ctx.beginPath();
  ctx.moveTo(0, canvas.height);

  for (let x = 0; x <= canvas.width; x += 18) {
    const y =
      canvas.height -
      70 +
      Math.sin((x + time) * 0.015) * 22 +
      Math.sin((x + time * 1.6) * 0.045) * 8;

    ctx.lineTo(x, y);
  }

  ctx.lineTo(canvas.width, canvas.height);
  ctx.closePath();

  const grad = ctx.createLinearGradient(
    0,
    canvas.height - 160,
    0,
    canvas.height
  );
  grad.addColorStop(0, "rgba(79,223,255,0.15)");
  grad.addColorStop(1, "rgba(59,255,179,0.35)");

  ctx.fillStyle = grad;
  ctx.fill();
}

// -------- LOOP --------
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawWave();
  drawBubbles();

  time += 1.2;
  requestAnimationFrame(animate);
}

animate();
