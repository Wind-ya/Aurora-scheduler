/* =========================
   LOGIN & REGISTER
========================= */
function register() {
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (!name || !email || !password) {
    alert("Lengkapi semua data!");
    return;
  }

  localStorage.setItem("user", JSON.stringify({ name, email, password }));
  alert("Pendaftaran berhasil! Silakan login.");
}

function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  const user = JSON.parse(localStorage.getItem("user"));
  if (!user) {
    alert("Belum ada akun, silakan daftar dulu.");
    return;
  }

  if (email === user.email && password === user.password) {
    alert("Login berhasil! Selamat datang " + user.name);
  } else {
    alert("Email atau password salah!");
  }
}

/* =========================
   CANVAS SETUP
========================= */
const canvas = document.getElementById("fxCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let time = 0;

/* =========================
   PARTIKEL KECIL (BACKGROUND)
========================= */
const particles = [];

for (let i = 0; i < 40; i++) {
  particles.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    r: Math.random() * 3 + 1,
    speed: Math.random() * 0.25 + 0.1,
    alpha: Math.random() * 0.4 + 0.2
  });
}

function drawParticles() {
  particles.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(120,220,255,${p.alpha})`;
    ctx.fill();

    p.y -= p.speed;
    if (p.y < -10) {
      p.y = canvas.height + 10;
      p.x = Math.random() * canvas.width;
    }
  });
}

/* =========================
   WAVE (CAIR & TIDAK BERATURAN)
========================= */
function drawWave() {
  ctx.beginPath();
  ctx.moveTo(0, canvas.height);

  for (let x = 0; x <= canvas.width; x += 20) {
    const base =
      Math.sin((x + time) * 0.012) * 18;
    const noise =
      Math.sin((x + time * 1.6) * 0.04) * 7;

    const y = canvas.height - 80 + base + noise;
    ctx.lineTo(x, y);
  }

  ctx.lineTo(canvas.width, canvas.height);
  ctx.closePath();

  const grad = ctx.createLinearGradient(
    0,
    canvas.height - 160,
    0,
    canvas.height
  );
grad.addColorStop(0, "rgba(79,223,255,0.08)");
grad.addColorStop(1, "rgba(59,255,179,0.18)");


  ctx.fillStyle = grad;
  ctx.fill();
}

/* =========================
   LAVA BLOBS (ELEMEN UTAMA)
========================= */
const blobs = [];

function createBlob() {
  return {
    x: Math.random() < 0.5
      ? Math.random() * canvas.width * 0.3   // kiri
      : canvas.width * 0.7 + Math.random() * canvas.width * 0.3, // kanan
    y: canvas.height + Math.random() * 80,
    rx: Math.random() * 22 + 18,   // LEBIH KECIL
    ry: Math.random() * 50 + 40,   // LANGSING
    vy: Math.random() * 0.12 + 0.08, // SUPER PELAN
    phase: Math.random() * Math.PI * 2,
    alpha: Math.random() * 0.18 + 0.12 // LEBIH HALUS
  };
}

for (let i = 0; i < 8; i++) {
  blobs.push(createBlob());
}

function drawBlobs() {


  blobs.forEach((b, i) => {
    b.y -= b.vy;
    b.phase += 0.008;

   const sx = 1 + Math.sin(b.phase) * 0.04;
const sy = 1 - Math.sin(b.phase) * 0.06;


    ctx.save();
    ctx.translate(b.x, b.y);
    ctx.scale(sx, sy);

    ctx.beginPath();
    ctx.ellipse(0, 0, b.rx, b.ry, 0, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(59,255,179,${b.alpha})`;
    ctx.fill();
    ctx.restore();

    if (b.y + b.ry < -120) {
      blobs[i] = createBlob();
    }
  });

  ctx.globalCompositeOperation = "source-over";
}

/* =========================
   ANIMATION LOOP (SATU)
========================= */
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  drawParticles(); // latar
  drawWave();      // dasar cair
  drawBlobs();     // lava utama

  time += 0.35;    // ⬅️ kunci: PELAN
  requestAnimationFrame(animate);
}

animate();

/* =========================
   RESPONSIVE
========================= */
window.addEventListener("resize", () => {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
});
