// =====================
// AMBIL ELEMENT UTAMA
// =====================
const cards = document.querySelectorAll(".type-card");
const modal = document.getElementById("mainModal");
const modalTitle = document.getElementById("modalTitle");
const modalContent = document.getElementById("modalContent");
const closeBtn = document.getElementById("closeModal");
const submitBtn = document.getElementById("submitBtn");

// =====================
// EVENT KLIK GRID
// =====================
cards.forEach(card => {
  card.addEventListener("click", () => {
    const type = card.dataset.type;
    openModal(type);
  });
});

// =====================
// CLOSE MODAL
// =====================
closeBtn.addEventListener("click", closeModal);
modal.addEventListener("click", e => {
  if (e.target === modal) closeModal();
});
submitBtn.addEventListener("click", () => {
  // nanti: logic simpan data
  closeModal();
});

function closeModal() {
  modal.style.display = "none";
}

// =====================
// OPEN MODAL DINAMIS
// =====================
function openModal(type) {
  modal.style.display = "flex";
  modalTitle.innerText = "";
  modalContent.innerHTML = "";

  switch (type) {
    case "tugas":
      modalTitle.innerText = "Tambah Tugas";
      modalContent.innerHTML = tugasForm();
      break;

    case "acara":
      modalTitle.innerText = "Tambah Acara";
      modalContent.innerHTML = acaraForm();
      break;

    case "ulangtahun":
      modalTitle.innerText = "Tambah Ulang Tahun";
      modalContent.innerHTML = ultahForm();
      break;

    case "keagamaan":
      modalTitle.innerText = "Tambah Acara Keagamaan";
      modalContent.innerHTML = keagamaanForm();
      break;

    case "peringatan":
      modalTitle.innerText = "Tambah Peringatan";
      modalContent.innerHTML = peringatanForm();
      break;

    case "penting":
      modalTitle.innerText = "Tambah Acara Penting";
      modalContent.innerHTML = pentingForm();
      break;

    case "lainnya":
      modalTitle.innerText = "Tambah Jadwal Lainnya";
      modalContent.innerHTML = lainnyaForm();
      break;
  }
}

// =====================
// TEMPLATE FORM
// =====================
function tugasForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Nama Tugas</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal Mulai</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Tanggal Akhir</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Tingkat Kesulitan</label>
      <select>
        <option>Mudah</option>
        <option>Sedang</option>
        <option>Sulit</option>
      </select>
    </div>

    <div class="form-group">
      <label>Nama Dosen</label>
      <input type="text">
    </div>

    <div class="form-group full">
      <label>Deskripsi</label>
      <textarea></textarea>
    </div>

    <div class="form-group full">
      <label>Jenis Tugas</label>
      <input type="text">
    </div>
  </div>`;
}

function acaraForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Nama Acara</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Jam Mulai</label>
      <input type="time">
    </div>

    <div class="form-group">
      <label>Jam Selesai</label>
      <input type="time">
    </div>

    <div class="form-group full">
      <label>Lokasi</label>
      <input type="text">
    </div>

    <div class="form-group full">
      <label>Deskripsi</label>
      <textarea></textarea>
    </div>
  </div>`;
}

function ultahForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Nama Orang</label>
      <input type="text">
    </div>

    <div class="form-group full">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group full checkbox">
      <label>
        <input type="checkbox"> Ulang setiap tahun
      </label>
    </div>
  </div>`;
}

function keagamaanForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Nama Acara</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Waktu (opsional)</label>
      <input type="time">
    </div>

    <div class="form-group full checkbox">
      <label>
        <input type="checkbox"> Berulang setiap tahun
      </label>
    </div>

    <div class="form-group full">
      <label>Keterangan</label>
      <textarea></textarea>
    </div>
  </div>`;
}

function peringatanForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Judul</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Waktu Pengingat</label>
      <input type="time">
    </div>
  </div>`;
}

function pentingForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Nama Acara</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Jam Dimulai</label>
      <input type="time">
    </div>

    <div class="form-group">
      <label>Kepentingan</label>
      <select>
        <option>Sangat Penting</option>
        <option>Penting</option>
        <option>Cukup Penting</option>
      </select>
    </div>

    <div class="form-group full">
      <label>Bersama Siapa</label>
      <input type="text">
    </div>

    <div class="form-group full">
      <label>Acara Tentang Apa</label>
      <textarea></textarea>
    </div>

    <div class="form-group full">
      <label>Nama Orang Penting</label>
      <input type="text">
    </div>
  </div>`;
}

function lainnyaForm() {
  return `
  <div class="form-grid">
    <div class="form-group full">
      <label>Judul Kegiatan</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Tanggal</label>
      <input type="date">
    </div>

    <div class="form-group">
      <label>Waktu (opsional)</label>
      <input type="time">
    </div>

    <div class="form-group full">
      <label>Kategori</label>
      <input type="text">
    </div>

    <div class="form-group">
      <label>Prioritas</label>
      <select>
        <option>Rendah</option>
        <option>Sedang</option>
        <option>Tinggi</option>
      </select>
    </div>

    <div class="form-group full">
      <label>Catatan</label>
      <textarea></textarea>
    </div>

    <div class="form-group full checkbox">
      <label>
        <input type="checkbox"> Aktifkan pengingat
      </label>
    </div>
  </div>`;
}


// =====================
// BACKGROUND WAVE + BUBBLE
// =====================
const bgCanvas = document.getElementById("bgCanvas");
const bgCtx = bgCanvas.getContext("2d");

function resizeCanvas() {
  bgCanvas.width = window.innerWidth;
  bgCanvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener("resize", resizeCanvas);

let time = 0;

// ===== BUBBLES =====
const bubbles = Array.from({ length: 22 }, () => createBubble());

function createBubble() {
  return {
    x: Math.random() * bgCanvas.width,
    y: bgCanvas.height + Math.random() * 200,
    r: Math.random() * 10 + 6,
    speed: Math.random() * 0.4 + 0.2,
    drift: Math.random() * 1000,
    alpha: Math.random() * 0.25 + 0.25
  };
}

// ===== DRAW WAVE =====
function drawWave() {
  bgCtx.beginPath();
  bgCtx.moveTo(0, bgCanvas.height);

  for (let x = 0; x <= bgCanvas.width; x += 18) {
    const y =
      bgCanvas.height -
      70 +
      Math.sin((x + time) * 0.015) * 22 +
      Math.sin((x + time * 1.5) * 0.045) * 8;

    bgCtx.lineTo(x, y);
  }

  bgCtx.lineTo(bgCanvas.width, bgCanvas.height);
  bgCtx.closePath();

  const gradient = bgCtx.createLinearGradient(
    0,
    bgCanvas.height - 160,
    0,
    bgCanvas.height
  );
  gradient.addColorStop(0, "rgba(79,223,255,0.15)");
  gradient.addColorStop(1, "rgba(59,255,179,0.35)");

  bgCtx.fillStyle = gradient;
  bgCtx.fill();
}

// ===== DRAW BUBBLES =====
function drawBubbles() {
  bubbles.forEach((b, i) => {
    b.drift += 0.01;
    b.x += Math.sin(b.drift) * 0.25;
    b.y -= b.speed;

    bgCtx.beginPath();
    bgCtx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    bgCtx.fillStyle = `rgba(59,255,179,${b.alpha})`;
    bgCtx.fill();

    if (b.y < -50) {
      bubbles[i] = createBubble();
    }
  });
}

// ===== ANIMATION LOOP =====
function animateBg() {
  bgCtx.clearRect(0, 0, bgCanvas.width, bgCanvas.height);

  drawWave();
  drawBubbles();

  time += 1.2;
  requestAnimationFrame(animateBg);
}

animateBg();
